int main() {
    printf("hellow, world!\n");
}
