#include <stdio.h>

int main() {
    printf("hellow, world!\n");
    return 0;
}
